import java.util.Scanner;

public class Survey {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int choice;

        //Ques 1
        System.out.println("What type of habitat do you have in your field ?");
        System.out.println("A. Mountains");
        System.out.println("B. Plains");
        System.out.println("C. Dessert");
        System.out.println("D. Wetlands");
        String answer1 = scan.nextLine();

        //Ques 2
        System.out.println("How much sunlight reaches your field");
        System.out.println("A. Its dark.");
        System.out.println("B. Its average.");
        System.out.println("C. Its bright.");
        System.out.println("D. Its almost a drought here.");
        String answer2 = scan.nextLine();
        //Ques 3
        System.out.println("What tools can you afford");
        System.out.println("A. Old");
        System.out.println("B. New");
        String answer3 = scan.nextLine();
        scan.close();

        if (answer1 .equals("A")) {
             System.out.println("Use Terrace farming. Grow Potatoes, Barley, Apples, Berries, Cabbage and Cruciferous Vegetables. For Question 1");
        } else if (answer1 .equals("B")) {
             System.out.println("You have wide range. Grow Wheat, Cotton, Sugar beans, Soybeans, Peanuts, Sunflower etc. For Question 1"); 
        }else if (answer1 .equals("C")) {
            System.out.println("Rely heavily on water efficiency. Water reuse, desalination, and drip irrigation are just a few of the modern ways that arid-climate region. For Question 1");
            System.out.println("You can grow ALOVERA, CACTUS, DATES, AGAVE AND DESSERT FRUITS. For Question 1");
        } else if (answer1 .equals("D")) {
            System.out.println("Keep your water levels in check. You can grow RICE, CRANBERRIES, WATER CHESTNUTS AND LOTUSES. For Question 1");
        } else {
            System.out.println("INVALID INPUT For Question 1");
            System.exit(0);
        }
           
                if (answer2 .equals("A")) {
             System.out.println("Trim the trees if there are some that are bloking the sunlight");
             System.out.println("Soil improvement or Relocation");
             System.out.println("In extreme cases us artifical lighting");
             System.out.println("For Question 2");
        } else if (answer2 .equals("B")) {
             System.out.println("It is then perfect. For Question 2"); 
        }else if (answer2 .equals("C")) {
            System.out.println("Use light coloured material or Harvesting in cooler period");
            System.out.println("But do not worry too much even if you dont follow these suggestions your crops wont Suffer");
            System.out.println("For Question 2");
        } else if (answer2 .equals("D")) {
            System.out.println("Provide shade to crops using sheds or cloth ");
            System.out.println("Plan your planting schedule to avoid the hottest and sunniest periods of the year, if possible.");
            System.out.println("Companion planting: Use trees or plants as shade for you crops * best method eco friendly.");
            System.out.println("For Question 2");
        } else {
            System.out.println("INVALID INPUT For Question 2");
            System.exit(0);
        }
            if (answer3 .equals("A")) {
                System.out.println("We suggest to expand your budget but you can use NATURAL MANURES (BETTER THAN FERTILISRES)");
                System.out.println("PLOUGH OR HOE INSTED OF TRACTOR (eco friendly)");
                System.out.println("traditional methods of irrigation.");
                System.out.println("For Question 3");
             } else if (answer3.equals("B")){
                   System.out.println("Use tractors, Still suggesting manures, Use modern methods of irrigation like drip irrigation, sprinkler");
                   System.out.println("For Question 3");
            } else {
             System.out.println("INVALID INPUT For Question 3");
             System.exit(0);               
            }
        


    }
}
