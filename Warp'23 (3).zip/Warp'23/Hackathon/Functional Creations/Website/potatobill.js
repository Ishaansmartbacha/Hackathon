x = prompt("What quantity of Potatoes are you buying? X1")
document.write("Your bill is : ", x*30)