x = prompt("What quantity of Capsicum are you buying? X1")
document.write("Your bill is : ", x*60)