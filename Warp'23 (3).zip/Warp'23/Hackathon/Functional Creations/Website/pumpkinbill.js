x = prompt("What quantity of Pumpkin are you buying? X1")
document.write("Your bill is : ", x*30)